import sys,json,hashlib,subprocess,statistics,time,platform
from pathlib import Path
sys.path.insert(0,str(Path("scripts/benchmark").resolve()))
import compare,mature
out=Path("/tmp/kkscreeps-generic-abba");out.mkdir()
warmup,ticks,concurrency=30,100,4
fixture=mature.fixture(50,warmup+ticks,warmup=warmup)
fp=out/"fixture-50.json";fp.write_text(json.dumps(fixture))
paths={"old":Path("/tmp/kkscreeps-generic-baseline-bin"),"new":Path("/tmp/kkscreeps-generic-optimized-bin")}
expected={"old":"a8e68dbcbe4425b2223cb5cf508a5b006a1df43d75b3e70aca147d51705d123e","new":"45c6961fbd43ceb1f38915680956d9fd43c1b1bdb7bd44ce138073dda0139bcb"}
for k,p in paths.items(): assert compare.digest(p)==expected[k]
provenance={"scope":"same-engine ABBA, no new xxs comparison or formal acceptance","order":["old","new","new","old"],"warmup":warmup,"ticks":ticks,"concurrency":concurrency,"binary_sha256":expected,"fixture_sha256":compare.digest(fp),"patch_sha256":compare.digest("/tmp/kkscreeps-generic-abba-start.patch"),"machine":platform.platform(),"started_unix":time.time(),"baseline_source_provenance":json.load(open("/tmp/kkscreeps-generic-identity-before/provenance.json")),"new_source_provenance":json.load(open("/tmp/kkscreeps-generic-identity-after/provenance.json"))}
(out/"provenance.json").write_text(json.dumps(provenance,ensure_ascii=False,indent=2))
reports=[];rows=[]
for i,k in enumerate(provenance["order"],1):
 name=f"{i}-{k}";rp=out/(name+".json")
 cmd=[str(paths[k]),"compare-probe","--fixture",str(fp),"--warmup",str(warmup),"--ticks",str(ticks),"--concurrency",str(concurrency),"--report",str(rp)]
 with (out/(name+".log")).open("w") as log: subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 report=json.loads(rp.read_text());compare.validate(report,fixture,warmup,ticks,concurrency)
 if reports:
  for stage in ["initial","before","after"]: assert compare.first_difference(reports[0][stage],report[stage]) is None,stage
  assert compare.counters(reports[0])==compare.counters(report),"completion counters"
 phases=report["phases"]["phases"];process=report["process"]
 row={"order":i,"version":k,"wall":phases["wall"],"project":phases["project"]["p50_ms"],"run":phases["run"]["p50_ms"],"settle":phases["settle"]["p50_ms"],"cpu":process["cpu_core_ms_per_tick"],"rss_p50":process["rss_bytes_sampled_p50"],"rss_peak":process["rss_bytes_sampled_peak"]}
 rows.append(row);reports.append(report)
 (out/"progress.json").write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
summary={"success":True,"equivalent":True,"completion_counters_equal":True,"formal_window":False,"rows":rows,"aggregate":{}}
for k in ["old","new"]:
 selected=[r for r in rows if r["version"]==k]
 summary["aggregate"][k]={**{key:statistics.mean(r[key] for r in selected) for key in ["cpu","rss_p50","rss_peak","project","run","settle"]},**{key:statistics.mean(r["wall"][key] for r in selected) for key in ["p50_ms","p95_ms","p99_ms"]}}
summary["new_over_old"]={k:summary["aggregate"]["new"][k]/v for k,v in summary["aggregate"]["old"].items()}
(out/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary["new_over_old"]),flush=True)
